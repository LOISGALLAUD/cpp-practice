#!/bin/sh
cd build/
make
cd ..
./bin/monExe

