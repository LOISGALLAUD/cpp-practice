#include <iostream>

int main() {
    std::cout<<"Bonjour"<<std::endl;
}